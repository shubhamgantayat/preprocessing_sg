from setuptools import setup

setup(name='preprocessing_sg',
      version='0.0',
      description='Data Processing Functions',
      packages=['preprocessing_sg'],
      author_email='sgantayat9@gmail.com',
      zip_safe=False)
